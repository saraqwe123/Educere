<?php
include_once('conexaoBD.php');

// Verificando se houve um envio do formulário
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $categoria = $_POST['categoria'];
    $nome = $_POST['nome'];
    $marca = $_POST['marca'];
    $local = $_POST['local'];
    $data = $_POST['data'];
    $valor = (float)$_POST['valor']; 
    $energia = $_POST['energia'];
    $descricao = $_POST['descricao'];
    $foto = $_POST['foto'];

    $stmt = $conexao->prepare("INSERT INTO itens (categoria, nome, marca, local, data, valor, energia, descricao, foto) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param("sssssssss", $categoria, $nome, $marca, $local, $data, $valor, $energia, $descricao, $foto);

    if ($stmt->execute()) {
        include("phpqrcode/qrlib.php");

        $resultado = $conexao->query("SELECT * FROM itens");

        if ($resultado->num_rows > 0) {
            while ($row = $resultado->fetch_assoc()) {
                $id = $row["id"];
                $nome = $row["nome"];
                $categoria = $row["categoria"];
                $local = $row["local"];
                $descricao = $row["descricao"];
                $foto = $row["foto"];
                $data = $row["data"];

                $dados = $dados = "Nome: $nome\nCategoria: $categoria\nLocal: $local\nDescrição: $descricao\nFoto: $foto\nData: $data";

                $qr = "../ENTITIES/Item/qrcode/qr_$id.png";
                QRcode::png($dados, $qr, "L", 4, 2);

                $update_sql = "UPDATE itens SET qr_code_path='$qr' WHERE id=$id";
                $conexao->query($update_sql);
            }

            if ($conexao->query($update_sql)) {
                echo "QR Code gerado e caminho atualizado para ID $id.<br>";
            } else {
                echo "Erro ao atualizar registro com ID $id: " . $conexao->error . "<br>";
            }
        }
        else {
            echo "Erro ao inserir dados: ". $stmt->error;
        }

    } else {
        echo "Erro ao inserir dados: ". $stmt->error;
    }  

$stmt->close();
}



